﻿<#
.SYNOPSIS
    优学院作业助手（桌面版）— 差量更新执行者（updater）。

.DESCRIPTION
    应用自己没法替换正在运行的 UTaskDesktop.exe / UTaskDesktop.dll —— Windows 会锁住
    这些文件。所以「替换」这一步交给本脚本，流程是：

      应用：下载增量包 → 校验 SHA256 → 解压到 %LOCALAPPDATA%\UTaskDesktop\update\staging
            → 写 task.json → 用 powershell 启动本脚本 → 应用自己退出
      本脚本：① 等主程序退出（最多 60 秒，超时强制结束）
              ② 备份将被覆盖/删除的文件到 backup\<旧版本>\
              ③ 用 staging 里的文件覆盖安装目录，删掉 patch 要求删除的文件
              ④ 逐个校验新文件的 SHA256
              ⑤ 成功 → 写 state.json → 启动应用
                 失败 → 用备份回滚 → 写 state.json（记失败原因）→ 启动旧版本

    本脚本随增量包一起下发（包里的 __patch/apply-update.ps1），所以它能单独修 bug，
    不用等下一次打安装包。用 PowerShell 而不是单独的 exe，是为了不再维护一个
    AOT 编译的小程序；系统自带 powershell.exe（Windows 10/11 的 5.1 就够）。

.PARAMETER TaskFile
    task.json 路径。缺省 %LOCALAPPDATA%\UTaskDesktop\update\task.json

.EXAMPLE
    powershell -NoProfile -ExecutionPolicy Bypass -File apply-update.ps1
#>
[CmdletBinding()]
param(
    [string]$TaskFile
)

$ErrorActionPreference = 'Stop'

# 日志文件在读到 task.json 之后才知道，所以先留空，Write-Log 会自己跳过。
$script:LogFile = $null

function Write-Log {
    param(
        [string]$Message,
        [string]$Level = 'INFO'
    )
    $line = '[{0}] [{1}] {2}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Write-Host $line
    if ($script:LogFile) {
        try { Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8 } catch { }
    }
}

# 统一的相对路径 → 绝对路径换算。清单里的路径一律用 / 分隔（跨平台一致），
# 到 Windows 本地要换成 \，并且必须挡住 .. 与绝对路径，避免包内容写到安装目录之外。
function ConvertTo-SafeFullPath {
    param(
        [string]$Root,
        [string]$RelativePath
    )
    $rel = $RelativePath -replace '/', '\'
    if ($rel -match '^[\\/]' -or $rel -match '^[A-Za-z]:' -or $rel -match '\.\.') {
        throw "清单里的路径不合法：$RelativePath"
    }
    return (Join-Path $Root $rel)
}

function Write-State {
    param(
        [string]$Result,
        [string]$Message,
        [string]$AppliedVersion
    )
    if (-not $script:StateFile) { return }
    $state = [ordered]@{
        schema          = 1
        appliedVersion  = $AppliedVersion
        previousVersion = $task.fromVersion
        targetVersion   = $task.toVersion
        lastResult      = $Result
        lastMessage     = $Message
        updatedAt       = (Get-Date).ToString('o')
    }
    try {
        $state | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $script:StateFile -Encoding UTF8
    }
    catch {
        Write-Log "写 state.json 失败：$($_.Exception.Message)" 'WARN'
    }
}

function Invoke-Rollback {
    param(
        [string]$BackupRoot,
        [object[]]$BackupIndex
    )
    Write-Log '开始回滚…' 'WARN'
    foreach ($entry in $BackupIndex) {
        try {
            $dst = ConvertTo-SafeFullPath -Root $task.installDir -RelativePath $entry.p
            if ($entry.existed) {
                $bak = ConvertTo-SafeFullPath -Root $BackupRoot -RelativePath $entry.p
                if (Test-Path -LiteralPath $bak) {
                    Copy-Item -LiteralPath $bak -Destination $dst -Force
                }
            }
            elseif (Test-Path -LiteralPath $dst) {
                # 原本不存在的文件（这次新加的）→ 回滚就是删掉它
                Remove-Item -LiteralPath $dst -Force
            }
        }
        catch {
            Write-Log "回滚 $($entry.p) 失败：$($_.Exception.Message)" 'ERROR'
        }
    }
}

# ── 0. 读 task.json ────────────────────────────────────────────────────────
if ([string]::IsNullOrWhiteSpace($TaskFile)) {
    $TaskFile = Join-Path $env:LOCALAPPDATA 'UTaskDesktop\update\task.json'
}
if (-not (Test-Path -LiteralPath $TaskFile)) {
    Write-Host "找不到 task.json：$TaskFile"
    exit 2
}

try {
    $task = Get-Content -LiteralPath $TaskFile -Raw -Encoding UTF8 | ConvertFrom-Json
}
catch {
    Write-Host "task.json 解析失败：$($_.Exception.Message)"
    exit 2
}

if ($task.logFile) {
    $script:LogFile = $task.logFile
    $logDir = Split-Path -Parent $script:LogFile
    if ($logDir -and -not (Test-Path -LiteralPath $logDir)) {
        New-Item -ItemType Directory -Force -Path $logDir | Out-Null
    }
}
if ($task.stateFile) { $script:StateFile = $task.stateFile }

$backupRoot = $task.backupDir
if ([string]::IsNullOrWhiteSpace($backupRoot)) {
    $backupRoot = Join-Path (Split-Path -Parent $TaskFile) ("backup\" + $task.fromVersion)
}

Write-Log ('=' * 60)
Write-Log "开始更新：$($task.fromVersion) → $($task.toVersion)"

if (-not (Test-Path -LiteralPath $task.installDir)) {
    Write-Log "安装目录不存在：$($task.installDir)" 'ERROR'
    Write-State -Result 'failed' -Message '安装目录不存在' -AppliedVersion $task.fromVersion
    exit 3
}

$exePath = Join-Path $task.installDir $task.exeName
$waitName = $task.waitProcessName
if ([string]::IsNullOrWhiteSpace($waitName)) {
    $waitName = [System.IO.Path]::GetFileNameWithoutExtension($task.exeName)
}

$exitCode = 1

try {
    # ── 1. 等主程序退出 ────────────────────────────────────────────────────
    $deadline = (Get-Date).AddSeconds(60)
    while ($true) {
        $running = Get-Process -Name $waitName -ErrorAction SilentlyContinue
        if (-not $running) { break }
        if ((Get-Date) -gt $deadline) {
            Write-Log '主程序 60 秒内没有退出，强制结束（与安装程序的 taskkill 做法一致）' 'WARN'
            & taskkill.exe /F /IM $task.exeName 2>&1 | Out-Null
            Start-Sleep -Milliseconds 1500
            break
        }
        Start-Sleep -Milliseconds 400
    }
    # 再给文件句柄一点释放时间
    Start-Sleep -Milliseconds 600
    Write-Log '主程序已退出，开始替换文件'

    # ── 2. 备份将被覆盖/删除的文件 ────────────────────────────────────────
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    $targets = @()
    foreach ($f in $task.files) { $targets += $f.p }
    foreach ($r in $task.remove) { $targets += $r }
    $targets = $targets | Select-Object -Unique

    $backupIndex = New-Object System.Collections.ArrayList
    $backupCount = 0
    foreach ($rel in $targets) {
        $dst = ConvertTo-SafeFullPath -Root $task.installDir -RelativePath $rel
        $existed = Test-Path -LiteralPath $dst
        [void]$backupIndex.Add([pscustomobject]@{ p = $rel; existed = $existed })
        if ($existed) {
            $bak = ConvertTo-SafeFullPath -Root $backupRoot -RelativePath $rel
            $bakDir = Split-Path -Parent $bak
            if ($bakDir -and -not (Test-Path -LiteralPath $bakDir)) {
                New-Item -ItemType Directory -Force -Path $bakDir | Out-Null
            }
            Copy-Item -LiteralPath $dst -Destination $bak -Force
            $backupCount++
        }
    }
    $backupIndex | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $backupRoot 'backup-index.json') -Encoding UTF8
    Write-Log "已备份 $backupCount 个文件到 $backupRoot"

    # ── 3. 覆盖 + 删除 ────────────────────────────────────────────────────
    $stagingRoot = (Resolve-Path -LiteralPath $task.stagingDir).Path
    $written = 0
    foreach ($f in $task.files) {
        $src = ConvertTo-SafeFullPath -Root $stagingRoot -RelativePath $f.p
        if (-not (Test-Path -LiteralPath $src)) {
            throw "增量包里缺少文件：$($f.p)"
        }
        $dst = ConvertTo-SafeFullPath -Root $task.installDir -RelativePath $f.p
        $dstDir = Split-Path -Parent $dst
        if ($dstDir -and -not (Test-Path -LiteralPath $dstDir)) {
            New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
        }
        if (Test-Path -LiteralPath $dst) {
            # 旧安装包解出来的文件可能带只读属性，Copy-Item -Force 覆盖不了只读文件，先清掉
            try { (Get-Item -LiteralPath $dst -Force).IsReadOnly = $false } catch { }
        }
        Copy-Item -LiteralPath $src -Destination $dst -Force
        $written++
    }
    Write-Log "已写入 $written 个文件"

    $removed = 0
    foreach ($r in $task.remove) {
        $dst = ConvertTo-SafeFullPath -Root $task.installDir -RelativePath $r
        if (Test-Path -LiteralPath $dst) {
            try { (Get-Item -LiteralPath $dst -Force).IsReadOnly = $false } catch { }
            Remove-Item -LiteralPath $dst -Force
            $removed++
        }
    }
    if ($removed -gt 0) { Write-Log "已删除 $removed 个过期文件" }

    # ── 4. 逐个校验 ───────────────────────────────────────────────────────
    $verified = 0
    foreach ($f in $task.files) {
        $dst = ConvertTo-SafeFullPath -Root $task.installDir -RelativePath $f.p
        $actual = (Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash
        if ($actual -ne $f.h.ToUpperInvariant()) {
            throw "校验不通过：$($f.p)（期望 $($f.h)，实际 $actual）"
        }
        $verified++
    }
    Write-Log "校验通过：$verified 个文件"

    # ── 5. 成功 ───────────────────────────────────────────────────────────
    Write-State -Result 'ok' -Message '更新完成' -AppliedVersion $task.toVersion
    Write-Log "更新完成：$($task.fromVersion) → $($task.toVersion)"

    # 文件已经替换并逐个校验通过，这一步再失败就不该回滚了 —— 旧文件已经没了，
    # 回滚只会把一份校验通过的新版本换成一份同样启动不了的旧版本。只记日志、给个非零退出码。
    try {
        if (-not (Test-Path -LiteralPath $exePath)) {
            throw "更新后找不到主程序：$exePath"
        }
        Start-Process -FilePath $exePath -WorkingDirectory $task.installDir
        Write-Log "已启动新版本：$exePath"
        $exitCode = 0
    }
    catch {
        Write-Log "启动新版本失败：$($_.Exception.Message)" 'WARN'
        $exitCode = 4
    }

    try { Remove-Item -LiteralPath $TaskFile -Force } catch { }
}
catch {
    $reason = $_.Exception.Message
    Write-Log "更新失败：$reason" 'ERROR'
    Invoke-Rollback -BackupRoot $backupRoot -BackupIndex $backupIndex
    Write-State -Result 'failed' -Message $reason -AppliedVersion $task.fromVersion
    if (Test-Path -LiteralPath $exePath) {
        Write-Log '已回滚，启动旧版本'
        try { Start-Process -FilePath $exePath -WorkingDirectory $task.installDir } catch { }
    }
    $exitCode = 1
}

exit $exitCode
